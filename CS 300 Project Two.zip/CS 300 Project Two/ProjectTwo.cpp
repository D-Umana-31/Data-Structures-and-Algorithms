/*Danielle Franklin
danielle.franklin@snhu.edu
December 15th 2024*/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <limits>

using namespace std;
/*Class to represent a course
course number
course title
prerequisties*/
class Course {
public:
    string number; 
    string title; 
    vector<string> prereqs;
    
    //constructor
    Course(string num, string t, vector<string> p) : number(num), title(t), prereqs(p) {}
};

/*TreeNode for node in BST
course data stored in node
pointer to left child node
pointer to right child node*/
class TreeNode {
public:
    Course course;
    TreeNode* leftChild;
    TreeNode* rightChild;

    //constructor
    TreeNode(Course c) : course(c), leftChild(nullptr), rightChild(nullptr) {}
};
//manages BST
class CourseTree {
public:
    TreeNode* root;

    //constructor
    CourseTree() : root(nullptr) {}

    //insert a course into tree
    TreeNode* insertCourse(TreeNode* node, Course course) {
        if (node == nullptr) {
            return new TreeNode(course);
        }
        if (course.number < node->course.number) {
            node->leftChild = insertCourse(node->leftChild, course);
        }
        else if (course.number > node->course.number) {
            node->rightChild = insertCourse(node->rightChild, course);
        }
        return node;
    }

    //print an alphanumeric list of courses
    void printCourseList(TreeNode* node) {
        if (node != nullptr) {
            printCourseList(node->leftChild);
            cout << node->course.number << ", " << node->course.title << endl;
            printCourseList(node->rightChild);
        }
    }

    //find a course in tree by course number
    TreeNode* findNode(TreeNode* node, const string& courseNum) {
        if (node == nullptr || node->course.number == courseNum) {
            return node;
        }
        if (courseNum < node->course.number) {
            return findNode(node->leftChild, courseNum);
        }
        return findNode(node->rightChild, courseNum);
    }
};
//read course from file and insert into tree
void readFile(const string& fileName, CourseTree& courseTree) {
    ifstream file(fileName);
    if (!file.is_open()) {
        cout << "Error: Could not open file " << fileName << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        vector<string> tokens;
        size_t start = 0, end;
        while ((end = line.find(',', start)) != string::npos) {
            tokens.push_back(line.substr(start, end - start));
            start = end + 1;
        }
        tokens.push_back(line.substr(start));

        if (tokens.size() < 2) {
            cout << "Error: Invalid data format in line: " << line << endl;
            continue;
        }

        string courseNum = tokens[0];
        string courseTitle = tokens[1];
        vector<string> prereqs(tokens.begin() + 2, tokens.end());

        Course course(courseNum, courseTitle, prereqs);
        courseTree.root = courseTree.insertCourse(courseTree.root, course);
    }

    file.close();
    cout << "File data loaded successfully." << endl;
}
//print details of a course
void printCourseDetails(CourseTree& courseTree, const string& courseNum) {
    TreeNode* node = courseTree.findNode(courseTree.root, courseNum);
    if (node == nullptr) {
        cout << "Course not found." << endl;
        return;
    }

    //print course details
    cout << node->course.number << ": " << node->course.title << endl;
    cout << "Prerequisites: ";
    for (const string& prereq : node->course.prereqs) {
        cout << prereq << " ";
    }
    cout << endl;
}

int main() {
    CourseTree courseTree;
    string fileName;
    bool dataLoaded = false;

    cout << "Enter the name of the data file: ";
    cin >> fileName;

    int choice = 0;

    while (true) {
        cout << "\nMenu Options:\n";
        cout << "1. Load the file data into the data structure.\n";
        cout << "2. Print an alphanumeric list of all the courses in the Computer Science department.\n";
        cout << "3. Print the course title and the prerequisites for any individual course.\n";
        cout << "9. Exit the program.\n";
        cout << "Enter your choice: ";

        //input validation
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a number from the menu options.\n";
            continue;
        }

        switch (choice) {
            //load file into data structure 
        case 1: {
            cout << "Loading file data...\n";
            readFile(fileName, courseTree);
            dataLoaded = true;
            break;
        }
              //print alphanumeric list
        case 2: {
            if (!dataLoaded) {
                cout << "Error: Data must be loaded before printing course information.\n";
            }
            else {
                cout << "Courses in the Computer Science department:\n";
                courseTree.printCourseList(courseTree.root);
            }
            break;
        }
              //print details of course
        case 3: {
            if (!dataLoaded) {
                cout << "Error: Data must be loaded before printing course information.\n";
            }
            else {
                string courseNum;
                cout << "Enter the course number: ";
                cin >> courseNum;
                printCourseDetails(courseTree, courseNum);
            }
            break;
        }
              //exit program
        case 9: {
            cout << "Exiting the program. Goodbye!\n";
            return 0;
        }
              //invail choices 
        default: {
            cout << "Invalid choice. Please enter a valid option from the menu.\n";
        }
        }
    }

    return 0;
}

